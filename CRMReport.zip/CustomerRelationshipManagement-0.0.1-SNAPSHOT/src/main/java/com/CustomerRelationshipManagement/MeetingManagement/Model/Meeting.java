package com.CustomerRelationshipManagement.MeetingManagement.Model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Meeting {
	@Id
	private long id;
}
