package com.CustomerRelationshipManagement.ReportManagement.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.CustomerRelationshipManagement.MeetingManagement.Model.Meeting;
import com.CustomerRelationshipManagement.ReportManagement.Model.Report;
import com.CustomerRelationshipManagement.ReportManagement.Service.ReportService;
import com.CustomerRelationshipManagement.ServiceManagement.Model.ServiceManagement;
import com.CustomerRelationshipManagement.UserManagement.Model.User;

@RestController
@RequestMapping("/api/reports")
public class ReportController {
	private final ReportService reportService;
	
	@Autowired
	public ReportController(ReportService reportService) {
		this.reportService = reportService;
	}
	
	/*@GetMapping("/check")
	public String check() {
		return "Hello";
	}*/
	
	@PostMapping("/generate")
	public Report generateReport(@RequestBody User user,@RequestBody List<ServiceManagement> services,@RequestBody List<Meeting> meetings){
		return reportService.generateReport(user, services, meetings);
	}
	
	@GetMapping("/viewById/{reportId}")
	public Report viewReport(@PathVariable Long reportId) {
		return reportService.viewReport(reportId);
	}
	
	@DeleteMapping("/delete/{reportId}")
	public boolean deleteReport(@PathVariable Long reportId) {
		return reportService.deleteReport(reportId);
	}
}
