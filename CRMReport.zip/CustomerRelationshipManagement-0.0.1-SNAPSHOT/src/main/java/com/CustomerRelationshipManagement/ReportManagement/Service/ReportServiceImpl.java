package com.CustomerRelationshipManagement.ReportManagement.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.CustomerRelationshipManagement.MeetingManagement.Model.Meeting;
import com.CustomerRelationshipManagement.ReportManagement.Model.Report;
import com.CustomerRelationshipManagement.ReportManagement.Repository.ReportRepository;
import com.CustomerRelationshipManagement.ServiceManagement.Model.ServiceManagement;
import com.CustomerRelationshipManagement.UserManagement.Model.User;


@Service
public class ReportServiceImpl implements ReportService{
 private final ReportRepository reportRepository;
 
 @Autowired
 public ReportServiceImpl(ReportRepository reportRepository) {
	 this.reportRepository = reportRepository;
 }
 
 @Override
 public Report generateReport(User user,List<ServiceManagement> services,List<Meeting> meetings) {
	 Report report = new Report();
	 report.setUser(user);
	 report.setServices(services);
	 report.setMeetings(meetings);
	 report.setReportGenerationDate(LocalDate.now());
	 return reportRepository.save(report);
 }
 
 @Override
 public Report viewReport(Long reportId){
	 return reportRepository.findById(reportId).orElse(null);
 }
 
 @Override
 public boolean deleteReport(Long reportId) {
	 Optional<Report> optionalReport = reportRepository.findById(reportId);
	 if(optionalReport.isPresent()) {
		 reportRepository.deleteById(reportId);
		 return true;
	 }
	 return false;
 }
}
