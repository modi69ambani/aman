package com.CustomerRelationshipManagement.ReportManagement.Model;

import java.time.LocalDate;
import java.util.List;

import com.CustomerRelationshipManagement.MeetingManagement.Model.Meeting;
import com.CustomerRelationshipManagement.ServiceManagement.Model.ServiceManagement;
import com.CustomerRelationshipManagement.UserManagement.Model.User;

import jakarta.persistence.*;

@Entity
public class Report {
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
private long reportId;

@ManyToOne
@JoinColumn(name = "userId")
private User user;

@OneToMany
private List<ServiceManagement> services;

@OneToMany
private List<Meeting> meetings;

private LocalDate reportGenerationDate;

public long getReportId() {
	return reportId;
}

public void setReportId(long reportId) {
	this.reportId = reportId;
}

public User getUser() {
	return user;
}

public void setUser(User user) {
	this.user = user;
}

public List<ServiceManagement> getServices() {
	return services;
}

public void setServices(List<ServiceManagement> services) {
	this.services = services;
}

public List<Meeting> getMeetings() {
	return meetings;
}

public void setMeetings(List<Meeting> meetings) {
	this.meetings = meetings;
}

public LocalDate getReportGenerationDate() {
	return reportGenerationDate;
}

public void setReportGenerationDate(LocalDate reportGenerationDate) {
	this.reportGenerationDate = reportGenerationDate;
}


}
