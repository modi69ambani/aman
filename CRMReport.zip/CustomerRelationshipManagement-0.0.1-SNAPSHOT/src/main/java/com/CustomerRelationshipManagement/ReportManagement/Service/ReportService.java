package com.CustomerRelationshipManagement.ReportManagement.Service;

import java.util.List;

import com.CustomerRelationshipManagement.MeetingManagement.Model.Meeting;
import com.CustomerRelationshipManagement.ReportManagement.Model.Report;
import com.CustomerRelationshipManagement.ServiceManagement.Model.ServiceManagement;
import com.CustomerRelationshipManagement.UserManagement.Model.User;

public interface ReportService {
	Report generateReport(User user,List<ServiceManagement> services,List<Meeting> meetings);
	Report viewReport(Long reportId);
	boolean deleteReport(Long reportId);
}
