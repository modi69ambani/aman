package com.CustomerRelationshipManagement.ServiceManagement.Model;
import com.CustomerRelationshipManagement.UserManagement.Model.User;

import jakarta.persistence.Column;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="Service")
public class ServiceManagement {
	    @Id
	    @GeneratedValue(strategy = GenerationType.AUTO)
	    private int serviceId;

	    @Column(nullable = false)
	    private String serviceName;

	    @Column(nullable = false)
	    private int estimatedDuration;

//	    @ElementCollection
	    private int teamMembersInvolved;

	    @Column(nullable = false)
	    private String serviceType;

	    @ManyToOne
	    @JoinColumn(name = "userId")
	    private User user;

	    public ServiceManagement(String serviceName, int estimatedDuration,int teamMembersInvolved, String serviceType, User user) {
	        this.serviceName = serviceName;
	        this.estimatedDuration = estimatedDuration;
	        this.teamMembersInvolved = teamMembersInvolved;
	        this.serviceType = serviceType;
	        this.user = user;
	    }

	    public int getServiceId() {
	        return serviceId;
	    }

	    public String getServiceName() {
	        return serviceName;
	    }

	    public int getEstimatedDuration() {
	        return estimatedDuration;
	    }

	    public int getTeamMembersInvolved() {
	        return teamMembersInvolved;
	    }

	    public String getServiceType() {
	        return serviceType;
	    }

	    public User getUser() {
	        return user;
	    }
}

