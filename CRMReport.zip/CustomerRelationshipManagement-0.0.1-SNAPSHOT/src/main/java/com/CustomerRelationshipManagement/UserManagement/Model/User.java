package com.CustomerRelationshipManagement.UserManagement.Model;

import java.util.Date;

import jakarta.annotation.Nonnull;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
 
@Entity
 
@Table(name = "User")
 
public class User {
    @Id
    @Column
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int userId;
    @Column
    @Nonnull
    private String firstName;
    @Column
    @Nonnull
    private String lastName;
    @Column
    @Nonnull
    private String emailAddress;
    @Column
    @Nonnull
    private String address;
    @Column
    @Nonnull
    private String mobileNumber;
    @Column
    private Date dateOfRegistration;
 
	public int getUserId() {
		return userId;
	}
 
	public void setUserId(int userId) {
		this.userId = userId;
	}
 
	public String getFirstName() {
		return firstName;
	}
 
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
 
	public String getLastName() {
		return lastName;
	}
 
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
 
	public String getEmailAddress() {
		return emailAddress;
	}
 
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
 
	public String getAddress() {
		return address;
	}
 
	public void setAddress(String address) {
		this.address = address;
	}
 
	public String getMobileNumber() {
		return mobileNumber;
	}
 
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
 
	public Date getDateOfRegistration() {
		return dateOfRegistration;
	}
 
	public void setDateOfRegistration(Date dateOfRegistration) {
		this.dateOfRegistration = dateOfRegistration;
	}
 
	public User(int userId, String firstName, String lastName, String emailAddress, String address, String mobileNumber,
			Date dateOfRegistration) {
		super();
		this.userId = userId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.emailAddress = emailAddress;
		this.address = address;
		this.mobileNumber = mobileNumber;
		this.dateOfRegistration = dateOfRegistration;
	}

 
}
 
